# -*- coding: utf-8 -*-
"""
Created on Thu Feb 15 12:59:37 2018

@author: toti.cavalcanti
"""

num = int(input())

print("Ho " * (num - 1) + "Ho!" )